package com.example.task3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
